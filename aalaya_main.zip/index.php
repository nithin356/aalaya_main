<?php
// Redirect root access to the user login page
header("Location: user/index.php");
exit();
?>
